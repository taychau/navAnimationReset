$(document).foundation();


// init click

// var animation = false;

// $(function() {
//     $("#knife")
//         .show();

// });

$('#knife').click(function() {
   console.log("click");

    var tween = new TimelineMax();

    // Leaf Being Thrown //

    
    tween.to('#lettuceHead', 0.75, {bezier:{autoRotate:false, 
        values:[{y:-10}, {y:-600}]}, ease:Quart.easeOut});
    tween.to('.lettuceRotate', 1, {rotation: 366}, '-=1');

    // Knife Swipe//
    tween.to('#knife', 0.75, {bezier:{autoRotate:false, 
        values:[{x:-150, y:250}, {x:-175, y:275}, {x:-200, y:300}, {x:-450, y:325} ]}, ease:Expo.easeIn}, '-=.75');
    tween.to('#knife', 0.4, {rotation: 92}, '-=0.2');

    // Lettuce Dissapears //
    tween.to('#lettuceHead', 0, {autoAlpha:0}, '-=0.3');

    // Halves Appear //
   
    tween.from("#leafLeft, #leafRight", 1, {css:{autoAlpha:0}}, '-=0.38');

    // Halves Fall //
    tween.to('#leafLeft', 0.75, {bezier:{autoRotate:false, 
        values:[{x:-80, y:20}, {x:-100, y:400}, {x:-120, y:450}]}, ease:Quart.easeOut}, '-=0.85');
    tween.to('#leafLeft', 0.4, {rotation: -12}, '-=0.85');

    tween.to('#leafRight', 0.75, {bezier:{autoRotate:false, 
        values:[{x:80, y:20}, {x:100, y:400}, {x:120, y:450}]}, ease:Quart.easeOut}, '-=0.85');
    tween.to('#leafRight', 0.4, {rotation: 12}, '-=0.85');


    // Halves Dissapear //
    tween.to('#leafLeft', 0.2, {autoAlpha:0}, '-=0.5');
    tween.to('#leafRight', 0.2, {autoAlpha:0}, '-=0.5');

    // X Appears //
       tween.to('#closeOut', 0.75, {bezier:{autoRotate:false, 
        values:[{x:320}]}, }, '-=0.3');
    tween.from("closeOut", 1, {css:{autoAlpha:0}}, '-=0.35');


    // Tabs Appear //
    tween.to('.home', 0.75, {bezier:{autoRotate:false, 
        values:[{x:160}]}, ease:Quart.easeIn}, '-=1');
    tween.from(".home", 1, {css:{autoAlpha:0}}, '-=0.35');

    tween.to('.history', 0.75, {bezier:{autoRotate:false, 
        values:[{x:150}]}, ease:Quart.easeIn}, '-=1');
    tween.from(".history", 1, {css:{autoAlpha:0}}, '-=0.35');

    tween.to('.recipes', 0.75, {bezier:{autoRotate:false, 
        values:[{x:150}]}, ease:Quart.easeIn}, '-=1');
    tween.from(".recipes", 1, {css:{autoAlpha:0}}, '-=0.35');




});






// init scoll magic
$('#closeOut').click(function() {

    TweenMax.to( '#tabs', ".5", {x: -400});

    TweenMax.set('#knife', {x:0, y: 0});
    // slide knife back on
    TweenMax.to( '#knife', ".5", {y: 100});

});






